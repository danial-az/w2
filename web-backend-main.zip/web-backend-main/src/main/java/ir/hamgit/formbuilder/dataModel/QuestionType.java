package ir.hamgit.formbuilder.dataModel;

public enum QuestionType {
    TEXT,
    EMAIL,
    TEXTAREA,
    CHECKBOX,
    RADIO,
    SELECT
}