package ir.hamgit.formbuilder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FormBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(FormBackendApplication.class, args);
    }

}
